'use strict';

Object.defineProperty(exports, "__esModule", {
  'value': true
});
const {
  ezra
} = require("../fredi/ezra");
ezra({
  'nomCom': "wagroup",
  'reaction': '🤨',
  'categorie': "Support-Owner",
  'nomFichier': __filename
}, async (_0x3258e7, _0x4c4732, _0x13b70c) => {
  console.log("Commande saisie !!!s");
  await _0x4c4732.sendMessage(_0x3258e7, {
    'text': "Hello 👋\n\nClick on the button below to join the OFFICIAL *DAVIBCS-MD* WhatsApp Gruop",
    'contextInfo': {
      'externalAdReply': {
        'sourceUrl': "",
        'mediaType': 0x1,
        'mediaUrl': "https://files.catbox.moe/oc5rvp.jpg",
        'title': "Join Our WhatsApp Group",
        'body': "Click to join the official DAVINCS-MD WhatsApp group!"
      }
    }
  });
  console.log("Command executed: wagroup");
});
ezra({
  'nomCom': 'wachannel',
  'reaction': '👀',
  'categorie': "Support-Owner",
  'nomFichier': __filename
}, async (_0x14c950, _0x346e6b, _0x31cbea) => {
  console.log("Commande saisie !!!s");
  await _0x346e6b.sendMessage(_0x14c950, {
    'text': "Hello 👋\n\nClick on the button below to Follow the OFFICIAL *DAVINCS-MD* WhatsApp Channel",
    'contextInfo': {
      'externalAdReply': {
        'sourceUrl': 'https://whatsapp.com/channel/0029VakSTEQGZNCk6CqE9E2P',
        'mediaType': 0x1,
        'mediaUrl': "https://files.catbox.moe/7irwqn.jpeg",
        'title': "Join Our WhatsApp Channel",
        'body': "Click to join the official DAVINCS-MD WhatsApp channel!"
      }
    }
  });
  console.log("Command executed: wachannel");
});
ezra({
  'nomCom': 'waowner',
  'reaction': '👀',
  'categorie': "Support-Owner",
  'nomFichier': __filename
}, async (_0x14c950, _0x346e6b, _0x31cbea) => {
  console.log("Commande saisie !!!s");
  await _0x346e6b.sendMessage(_0x14c950, {
    'text': "Hello 👋\n\nClick on the button below to contact the OFFICIAL *DAVINCS-MD* Owner",
    'contextInfo': {
      'externalAdReply': {
        'sourceUrl': 'https:// wa.me/255759637644',
        'mediaType': 0x1,
        'mediaUrl': "https://files.catbox.moe/lcori6.jpg",
        'title': "Join Our Developer Place",
        'body': "Click to join the official DAVINCS-MD Owner Inbox!"
      }
    }
  });
  console.log("Command executed: waowner");
});
ezra({
  'nomCom': 'fb-page',
  'reaction': '👀',
  'categorie': "Support-Owner",
  'nomFichier': __filename
}, async (_0x14c950, _0x346e6b, _0x31cbea) => {
  console.log("Commande saisie !!!s");
  await _0x346e6b.sendMessage(_0x14c950, {
    'text': "Hello 👋\n\nClick on the photo below to Follow the OFFICIAL *DAVINCSTECH* Facebook Page",
    'contextInfo': {
      'externalAdReply': {
        'sourceUrl': 'https://www.facebook.com/profile.php?id=100075936351162',
        'mediaType': 0x1,
        'mediaUrl': "https://files.catbox.moe/3np1r6.jpg",
        'title': "Follow Facebook Page 📄",
        'body': "Click to join the official DAVINCS-TECH Facebook Page!"
      }
    }
  });
  console.log("Command executed: fb-page");
});
ezra({
  'nomCom': 'insta-page',
  'reaction': '👀',
  'categorie': "Support-Owner",
  'nomFichier': __filename
}, async (_0x14c950, _0x346e6b, _0x31cbea) => {
  console.log("Commande saisie !!!s");
  await _0x346e6b.sendMessage(_0x14c950, {
    'text': "Hello 👋\n\nClick on the photo below to Follow the OFFICIAL *DAVINCS_TECH* Instagram Page",
    'contextInfo': {
      'externalAdReply': {
        'sourceUrl': 'https://www.instagram.com/allandavinc',
        'mediaType': 0x1,
        'mediaUrl': "https://files.catbox.moe/oc5rvp.jpg",
        'title': "Follow Instagram Page 📄",
        'body': "Click to join the official DAVINCS-tech Instagram Page!"
      }
    }
  });
  console.log("Command executed: insta-page");
});
ezra({
  'nomCom': 'threads-page',
  'reaction': '👀',
  'categorie': "Support-Owner",
  'nomFichier': __filename
}, async (_0x14c950, _0x346e6b, _0x31cbea) => {
  console.log("Commande saisie !!!s");
  await _0x346e6b.sendMessage(_0x14c950, {
    'text': "Hello 👋\n\nClick on the photo below to Follow the OFFICIAL *FREDIETECH* Threads Page",
    'contextInfo': {
      'externalAdReply': {
        'sourceUrl': 'https://www.threads.net/@f',
        'mediaType': 0x1,
        'mediaUrl': "https://files.catbox.moe/",
        'title': "Follow Threads Page 📄",
        'body': "Click to join the official DAVINCS_TECH Threads Page!"
      }
    }
  });
  console.log("Command executed: threads-page");
});
ezra({
  'nomCom': 'tiktok-page',
  'reaction': '👀',
  'categorie': "Support-Owner",
  'nomFichier': __filename
}, async (_0x14c950, _0x346e6b, _0x31cbea) => {
  console.log("Commande saisie !!!s");
  await _0x346e6b.sendMessage(_0x14c950, {
    'text': "Hello 👋\n\nClick on the photo below to Follow the OFFICIAL *DAVINCS-TECH* TikTok Page",
    'contextInfo': {
      'externalAdReply': {
        'sourceUrl': 'https://www.tiktok.com/@davincstech',
        'mediaType': 0x1,
        'mediaUrl': "https://files.catbox.moe/oc5rvp.jpg",
        'title': "Follow TikTok Page 📄",
        'body': "Click to join the official DAVINCS-TECH TikTok Page!"
      }
    }
  });
  console.log("Command executed: tiktok-page");
});
ezra({
  'nomCom': 'tgroup',
  'reaction': '👀',
  'categorie': "Support-Owner",
  'nomFichier': __filename
}, async (_0x14c950, _0x346e6b, _0x31cbea) => {
  console.log("Commande saisie !!!s");
  await _0x346e6b.sendMessage(_0x14c950, {
    'text': "Hello 👋\n\nClick on the photo below to Join the OFFICIAL *DAVINCS_MD* Telegram Group",
    'contextInfo': {
      'externalAdReply': {
        'sourceUrl': 'https://t.me/+u3zlb5y6Ofxh',
        'mediaType': 0x1,
        'mediaUrl': "https://files.catbox.moe/oc5rvp.jpg",
        'title': "Join Telegram Group📄",
        'body': "Click to join the official DAVINCS_MD Telegram Group!"
      }
    }
  });
  console.log("Command executed: tgroup");
});
ezra({
  'nomCom': 'ytchannel',
  'reaction': '👀',
  'categorie': "Support-Owner",
  'nomFichier': __filename
}, async (_0x14c950, _0x346e6b, _0x31cbea) => {
  console.log("Commande saisie !!!s");
  await _0x346e6b.sendMessage(_0x14c950, {
    'text': "Hello 👋\n\nClick on the photo below to Subscribe the OFFICIAL *DAVINCSTECH* YouTube Channel",
    'contextInfo': {
      'externalAdReply': {
        'sourceUrl': 'https://www.youtube.com/@davincis1724',
        'mediaType': 0x1,
        'mediaUrl': "https://files.catbox.moe/3np1r6.jpg",
        'title': "Follow YouTube Channel📄",
        'body': "Click to Subscribe the official DAVINCS_TECH YouTube Channel!"
      }
    }
  });
  console.log("Command executed: ytchannel");
});
ezra({
  'nomCom': 't-help',
  'reaction': '👀',
  'categorie': "Support-Owner",
  'nomFichier': __filename
}, async (_0x14c950, _0x346e6b, _0x31cbea) => {
  console.log("Commande saisie !!!s");
  await _0x346e6b.sendMessage(_0x14c950, {
    'text': "Hello 👋\n\nClick on the photo below to connect the OFFICIAL *DAVINCSTECH* Telegram Inbox",
    'contextInfo': {
      'externalAdReply': {
        'sourceUrl': 'https://t.me/Webernig',
        'mediaType': 0x1,
        'mediaUrl': "https://files.catbox.moe/6qm1zj.jpg",
        'title': "Chating With Owner",
        'body': "Click to Contact the official DAVINCS_TECH Telegram Inbox!"
      }
    }
  });
  console.log("Command executed: t-help");
});
