'use strict';

Object.defineProperty(exports, '__esModule', {
  'value': true
});
const {
  ezra
} = require("../fredi/ezra");
ezra({
  'nomCom': "wallpaper4",
  'reaction': '🎞',
  'nomFichier': __filename
}, async (_0x4388c3, _0x2d564f, _0x51d5cb) => {
  console.log("Commande saisie !!!s");
  await _0x2d564f.sendMessage(_0x4388c3, {
    'image': {
      'url': 'https://telegra.ph/file/6710065448c2367f23fcb.jpg'
    },
    'caption': "🚗𝗥𝗮𝗻𝗱𝗼𝗺 𝘄𝗮𝗹𝗹𝗽𝗮𝗽𝗲𝗿 \n\n 🚘Download it and set it to your wallpaper 𝗙𝗿𝗼𝗺 (DAVINCS-𝗠𝗗)🚗MADE BY DAVINCS tech"
  });
});
console.log("mon test");
